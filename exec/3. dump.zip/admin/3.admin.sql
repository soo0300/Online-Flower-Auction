insert into admin(created_date,last_modified_date,active,login_id, login_pw, name, tel, position)
values (now(),now(),1,'admin', 'Ssafyc204!', '김향기', '010-0111-1111', '00'),
	   (now(),now(),1,'lyt1228', 'pw1!', '임우택', '010-1111-1111', '10'),
       (now(),now(),1,'leeyr0412', 'pw2!', '이예리', '010-2222-2222', '10'),
       (now(),now(),1,'ghdgn22', 'pw3!', '홍승준', '010-3333-3333', '10'),
       (now(),now(),1,'seoyj505', 'pw4!', '서용준', '010-4444-4444', '10'),
       (now(),now(),1,'hans52410537', 'pw5!', '신성주', '010-5555-5555', '10'),
       (now(),now(),1,'soo0300', 'pw6!', '김수진', '010-6666-6666', '10');
       