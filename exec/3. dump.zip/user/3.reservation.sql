INSERT INTO reservation (reservation_id, count, price, grade, member_id, plant_Id, created_date, last_modified_date)
VALUES 
(1,10, 4450, 'NORMAL', 1, 112, '2023-08-16 12:34:56', '2023-08-16 12:34:56'),
(2,5, 8300, 'SUPER', 1, 199, '2023-08-16 12:34:56', '2023-08-16 12:34:56'),
(3,15, 2400, 'SUPER', 1, 314, '2023-08-16 12:34:56', '2023-08-16 12:34:56');